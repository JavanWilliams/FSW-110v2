//Nav Bar
var nav = document.createElement('nav');
document.getElementById()
var navList = document.createElement('ul');
var navOne = document.createElement('li');
var navTwo = document.createElement('li');
var navThree = document.createElement('li');

nav.appendChild(navList);
navList.appendChild(navOne);
navList.appendChild(navTwo);
navList.appendChild(navThree);

navOne.textContent = 'MMA';
navTwo.textContent = 'Boxing';
navThree.textContent = 'Kickboxing';

document.body.appendChild(nav);

var link = 
//h1 element
var headOne = document.createElement('h1');
headOne.textContent = 'The greatest Website ever';
document.body.appendChild(headOne);

//p element
var p = document.createElement('p');
p.textContent = 'Welcome to my site created with Javascript';
document.body.appendChild(p);

//List
/*var nav = document.createElement('nav');
var navList = document.createElement('ul');
var navOne = document.createElement('li');
var navTwo = document.createElement('li');
var navThree = document.createElement('li');

nav.appendChild(navList);
navList.appendChild(navOne);
navList.appendChild(navTwo);
navList.appendChild(navThree);

navOne.textContent = 'MMA';
navTwo.textContent = 'Boxing';
navThree.textContent = 'Kickboxing';

document.body.appendChild(nav);*/